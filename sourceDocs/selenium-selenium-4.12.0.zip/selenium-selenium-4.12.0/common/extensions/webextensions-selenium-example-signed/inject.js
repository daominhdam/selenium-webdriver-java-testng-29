((function(document) {
  var div = document.createElement('div');
  div.id = 'webextensions-selenium-example'
  div.textContent = "Content injected by webextensions-selenium-example";
  document.body.appendChild(div);
})(document))
